export default function Guest({ children }) {
    return <div>{children}</div>;
}
