import React from "react";

const TracksBoxes = (props) => {
    return <div></div>;
};

export default TracksBoxes;
