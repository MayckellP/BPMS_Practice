import React from "react";
import Webcam from "react-webcam";

const CamToLogistic = () => {
    return (
        <div>
            <Webcam />
        </div>
    );
};

export default CamToLogistic;
